// ==========================================================================
// Barebones OpenGL Core Profile Boilerplate
//    using the GLFW windowing system (http://www.glfw.org)
//
// Loosely based on
//  - Chris Wellons' example (https://github.com/skeeto/opengl-demo) and
//  - Camilla Berglund's example (http://www.glfw.org/docs/latest/quick.html)
//
// Author:  Sonny Chan, University of Calgary
// Co-Authors:
//			Jeremy Hart, University of Calgary
//			John Hall, University of Calgary
// Date:    December 2015
// ==========================================================================

#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>
#include <iterator>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "texture.h"
#include "GlyphExtractor.h"

GlyphExtractor Alphabet;

using namespace std;
using namespace glm;

bool flag = false;
int indicator =0;
float speed=0.0f;


string programQuadControl = "shaders/tessControl.glsl";
string programQuadEval = "shaders/tessEval.glsl";
string programQuadvertex = "shaders/vertex.glsl";
string programQuadfragment = "shaders/fragment.glsl";

string programCubeControl = "shaders/tessControlCube.glsl";
string programCubeEval = "shaders/tessEvalCube.glsl";
string programCubevertex = "shaders/vertex.glsl";
string programCubefragment = "shaders/fragment.glsl";

string programPointControl = "";
string programPointEval = "";
string programPointvertex = "shaders/vertexPoint.glsl";
string programPointfragment = "shaders/fragmentPoint.glsl";

//GLuint programQuad;
//GLuint programCube;
// --------------------------------------------------------------------------
// OpenGL utility and support function prototypes

void QueryGLVersion();
bool CheckGLErrors();

string LoadSource(const string &filename);
GLuint CompileShader(GLenum shaderType, const string &source);
GLuint LinkProgram(GLuint vertexShader, GLuint fragmentShader, GLuint tcsShader, GLuint tesShader);

// --------------------------------------------------------------------------
// Functions to set up OpenGL shader programs for rendering

// load, compile, and link shaders, returning true if successful
GLuint InitializeShaders(string controlname,string evalname,string vertexname,string fragmentname)
{
	// load shader source from files
	string vertexSource = LoadSource(vertexname);
	string fragmentSource = LoadSource(fragmentname);

	string tcsSource ;
	string tesSource ;

	if(controlname != "" || evalname != ""){
		tcsSource = LoadSource(controlname);
		tesSource = LoadSource(evalname);
	}
	if (vertexSource.empty() || fragmentSource.empty()) return 0;

	//string tcsSource = "";
	//string tesSource = "";
	// compile shader source into shader objects
	GLuint vertex = CompileShader(GL_VERTEX_SHADER, vertexSource);
	GLuint fragment = CompileShader(GL_FRAGMENT_SHADER, fragmentSource);
	GLuint tcs = CompileShader(GL_TESS_CONTROL_SHADER, tcsSource);
	GLuint tes = CompileShader(GL_TESS_EVALUATION_SHADER, tesSource);

	// link shader program
	if(controlname == "" || evalname == ""){
		tcs = 0;
		tes =0;
	}
	GLuint program = LinkProgram(vertex, fragment, tcs, tes);

	glDeleteShader(vertex);
	glDeleteShader(fragment);
	glDeleteShader(tcs);
	glDeleteShader(tes);

	if (CheckGLErrors())
		return 0;

	// check for OpenGL errors and return false if error occurred
	return program;
}

// --------------------------------------------------------------------------
// Functions to set up OpenGL buffers for storing geometry data

struct Geometry
{
	// OpenGL names for array buffer objects, vertex array object
	GLuint  vertexBuffer;
	GLuint  textureBuffer;
	GLuint  colourBuffer;
	GLuint  vertexArray;
	GLsizei elementCount;

	// initialize object names to zero (OpenGL reserved value)
	Geometry() : vertexBuffer(0), colourBuffer(0), vertexArray(0), elementCount(0)
	{}
};

bool InitializeVAO(Geometry *geometry){

	const GLuint VERTEX_INDEX = 0;
	const GLuint COLOUR_INDEX = 1;

	//Generate Vertex Buffer Objects
	// create an array buffer object for storing our vertices
	glGenBuffers(1, &geometry->vertexBuffer);

	// create another one for storing our colours
	glGenBuffers(1, &geometry->colourBuffer);

	//Set up Vertex Array Object
	// create a vertex array object encapsulating all our vertex attributes
	glGenVertexArrays(1, &geometry->vertexArray);
	glBindVertexArray(geometry->vertexArray);

	// associate the position array with the vertex array object
	glBindBuffer(GL_ARRAY_BUFFER, geometry->vertexBuffer);
	glVertexAttribPointer(
		VERTEX_INDEX,		//Attribute index 
		2, 					//# of components
		GL_FLOAT, 			//Type of component
		GL_FALSE, 			//Should be normalized?
		sizeof(vec2),		//Stride - can use 0 if tightly packed
		0);					//Offset to first element
	glEnableVertexAttribArray(VERTEX_INDEX);

	// associate the colour array with the vertex array object
	glBindBuffer(GL_ARRAY_BUFFER, geometry->colourBuffer);
	glVertexAttribPointer(
		COLOUR_INDEX,		//Attribute index 
		3, 					//# of components
		GL_FLOAT, 			//Type of component
		GL_FALSE, 			//Should be normalized?
		sizeof(vec3), 		//Stride - can use 0 if tightly packed
		0);					//Offset to first element
	glEnableVertexAttribArray(COLOUR_INDEX);

	// unbind our buffers, resetting to default state
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);

	return !CheckGLErrors();
}

// create buffers and fill with geometry data, returning true if successful
bool LoadGeometry(Geometry *geometry, vec2 *vertices, vec3 *colours, int elementCount)
{
	geometry->elementCount = elementCount;

	// create an array buffer object for storing our vertices
	glBindBuffer(GL_ARRAY_BUFFER, geometry->vertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vec2)*geometry->elementCount, vertices, GL_STATIC_DRAW);

	// create another one for storing our colours
	glBindBuffer(GL_ARRAY_BUFFER, geometry->colourBuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vec3)*geometry->elementCount, colours, GL_STATIC_DRAW);

	//Unbind buffer to reset to default state
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	// check for OpenGL errors and return false if error occurred
	return !CheckGLErrors();
}

// deallocate geometry-related objects
void DestroyGeometry(Geometry *geometry)
{
	// unbind and destroy our vertex array object and associated buffers
	glBindVertexArray(0);
	glDeleteVertexArrays(1, &geometry->vertexArray);
	glDeleteBuffers(1, &geometry->vertexBuffer);
	glDeleteBuffers(1, &geometry->colourBuffer);
}

// --------------------------------------------------------------------------
// Rendering function that draws our scene to the frame buffer

void RenderScene(Geometry *geometry, GLuint program)
{
	// clear screen to a dark grey colour
//	glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
//	glClear(GL_COLOR_BUFFER_BIT);

	// bind our shader program and the vertex array object containing our
	// scene geometry, then tell OpenGL to draw our geometry
	glUseProgram(program);
	glBindVertexArray(geometry->vertexArray);
	glDrawArrays(GL_PATCHES, 0, geometry->elementCount);

	// reset state to default (no shader or geometry bound)
	glBindVertexArray(0);
	glUseProgram(0);

	// check for an report any OpenGL errors
	CheckGLErrors();
}



void RenderPoint(Geometry *geometry, GLuint program){
	glUseProgram(program);
	glBindVertexArray(geometry->vertexArray);
	glDrawArrays(GL_POINTS, 0, geometry->elementCount);

	// reset state to default (no shader or geometry bound)
	glBindVertexArray(0);
	glUseProgram(0);

	// check for an report any OpenGL errors
	CheckGLErrors();
}


void drawPoint(vec2 vertices[],vec3 colours[],float number,GLuint program){
	Geometry geometry;
	if (!InitializeVAO(&geometry))
		cout << "Program failed to intialize geometry!" << endl;

	if(!LoadGeometry(&geometry, vertices, colours, number))
		cout << "Failed to load geometry" << endl;
	glPointSize(3);
	RenderPoint(&geometry, program);

	DestroyGeometry(&geometry);

}

void RenderLine(Geometry *geometry, GLuint program){
	glUseProgram(program);
	glBindVertexArray(geometry->vertexArray);
	glDrawArrays(GL_LINES, 0, geometry->elementCount);

	// reset state to default (no shader or geometry bound)
	glBindVertexArray(0);
	glUseProgram(0);

	// check for an report any OpenGL errors
	CheckGLErrors();
}

void drawLine(vec2 vertices[],vec3 colours[],float number,GLuint program){
	Geometry geometry;
	if (!InitializeVAO(&geometry))
		cout << "Program failed to intialize geometry!" << endl;

	if(!LoadGeometry(&geometry, vertices, colours, number))
		cout << "Failed to load geometry" << endl;
	
	RenderLine(&geometry, program);

	DestroyGeometry(&geometry);

}

void drawQuadraticCurve(vec2 vertices[],vec3 colours[],int size,GLuint program){
	Geometry geometry;
	if (!InitializeVAO(&geometry))
		cout << "Program failed to intialize geometry!" << endl;

	if(!LoadGeometry(&geometry, vertices, colours, size))
		cout << "Failed to load geometry" << endl;
	
	glPatchParameteri(GL_PATCH_VERTICES, 3);

	RenderScene(&geometry, program);

	DestroyGeometry(&geometry);

}


void drawCubicCurve(vec2 vertices[],vec3 colours[],int size,GLuint program){
	Geometry geometry;
	if (!InitializeVAO(&geometry))
		cout << "Program failed to intialize geometry!" << endl;

	if(!LoadGeometry(&geometry, vertices, colours, size))
		cout << "Failed to load geometry" << endl;
	
	glPatchParameteri(GL_PATCH_VERTICES, 4);

	RenderScene(&geometry, program);

	DestroyGeometry(&geometry);

}


float drawFont(string fontname,float adjust,float origin,float scale,char character,vec3 colours[],GLuint programPoint, GLuint programQuad, GLuint programCube){
	
	//Alphabet.LoadFontFile (fontname);

	MyGlyph p = Alphabet.ExtractGlyph(int(character));

		vector<vec2> Lines;
		vector<vec2> quad;
		vector<vec2> cube;
	//MySegment s;

	//create vector arrays that hold each of the points
	

for(int GlyphPiece =0;GlyphPiece < p.contours.size();GlyphPiece++){

	for(int patch =0;patch < p.contours[GlyphPiece].size();patch++){
			MySegment s = p.contours[GlyphPiece][patch];
		for(int i=0;i<s.degree +1;i++){
			vec2 point = vec2((s.x[i]/adjust)+scale/adjust-origin,(s.y[i]/adjust)-0.3);
			if(s.degree ==1){
				Lines.push_back(point);
			}
			if(s.degree ==2){
				quad.push_back(point);
			}
			if(s.degree ==3){
				cube.push_back(point);
			}
			//cout << s.x[i] << " " << s.y[i] << endl;
		}
	}
}


		drawLine(&Lines[0],colours,Lines.size(),programPoint);

		glPatchParameteri(GL_PATCH_VERTICES, 3);

		drawQuadraticCurve(&quad[0],colours,quad.size(),programQuad);

		glPatchParameteri(GL_PATCH_VERTICES, 4);


		drawCubicCurve(&cube[0],colours,cube.size(),programCube);

		return p.advance;
}

// --------------------------------------------------------------------------
// GLFW callback functions

// reports GLFW errors
void ErrorCallback(int error, const char* description)
{
	cout << "GLFW ERROR " << error << ":" << endl;
	cout << description << endl;
}

// handles keyboard input events
void KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GL_TRUE);

	if (key == GLFW_KEY_1 && action == GLFW_PRESS){
		indicator=0;
	}

	if (key == GLFW_KEY_2 && action == GLFW_PRESS){
		indicator =1;
	}
	if (key == GLFW_KEY_3 && action == GLFW_PRESS){
		indicator =2;
	}
	if (key == GLFW_KEY_4 && action == GLFW_PRESS){
		indicator =3;
	}
	if (key == GLFW_KEY_5 && action == GLFW_PRESS){
		indicator =4;
	}
	if (key == GLFW_KEY_6 && action == GLFW_PRESS){
		indicator =5;
	}
	if (key == GLFW_KEY_7 && action == GLFW_PRESS){
		indicator =6;
	}
	if (key == GLFW_KEY_8 && action == GLFW_PRESS){
		indicator =7;
	}
	if (key == GLFW_KEY_UP && action == GLFW_PRESS){
		speed+=0.01;
	}
	if (key == GLFW_KEY_DOWN && action == GLFW_PRESS){
		if(speed >=0){
			speed-= 0.01;
		}
		else
			speed =0.01f;
	}
}


// ==========================================================================
// PROGRAM ENTRY POINT



int main(int argc, char *argv[])
{
	// initialize the GLFW windowing system
	if (!glfwInit()) {
		cout << "ERROR: GLFW failed to initialize, TERMINATING" << endl;
		return -1;
	}
	glfwSetErrorCallback(ErrorCallback);

	// attempt to create a window with an OpenGL 4.1 core profile context
	GLFWwindow *window = 0;
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	int width = 512, height = 512;
	window = glfwCreateWindow(width, height, "CPSC 453 OpenGL Boilerplate", 0, 0);
	if (!window) {
		cout << "Program failed to create GLFW window, TERMINATING" << endl;
		glfwTerminate();
		return -1;
	}

	// set keyboard callback function and make our context current (active)
	glfwSetKeyCallback(window, KeyCallback);
	glfwMakeContextCurrent(window);

	//Intialize GLAD
	if (!gladLoadGL())
	{
		cout << "GLAD init failed" << endl;
		return -1;
	}

	// query and print out information about our OpenGL environment
	QueryGLVersion();

	GLuint programQuad = InitializeShaders(programQuadControl,programQuadEval,programQuadvertex,programQuadfragment);

	if (programQuad == 0) {
		cout << "Program could not initialize shaders, TERMINATING" << endl;
		return -1;
	}

	GLuint programCube = InitializeShaders(programCubeControl,programCubeEval,programCubevertex,programCubefragment);
	

	if (programCube == 0) {
		cout << "Program could not initialize shaders, TERMINATING" << endl;
		return -1;
	}
	
	GLuint programPoint = InitializeShaders(programPointControl,programPointEval,programPointvertex,programPointfragment);


	if (programPoint == 0) {
		cout << "Program could not initialize shaders, TERMINATING" << endl;
		return -1;
	}

	//GLuint program = InitializeShaders();
	//GLuint program = InitializeShaders();
	// call function to load and compile shader programs
	
	float scale = 0.38;
	vec2 verticesQuad[] = {
		vec2(1*scale, 1*scale),
		vec2(2*scale, -1*scale),
		vec2(0*scale, -1*scale),

		vec2(0*scale, -1*scale),
		vec2(-2*scale, -1*scale),
		vec2(-1*scale, 1*scale),

		vec2(-1*scale, 1*scale),
		vec2(0*scale, 1*scale),
		vec2(1*scale, 1*scale),

		vec2(1.2*scale, 0.5*scale),
		vec2(2.5*scale, 1.0*scale),
		vec2(1.3*scale, -0.4*scale)
					
	};

	vec2 verticesLine[] = {
		vec2(1*scale, 1*scale),
		vec2(2*scale, -1*scale),
		vec2(2*scale, -1*scale),
		vec2(0*scale, -1*scale),

		vec2(0*scale, -1*scale),
		vec2(-2*scale, -1*scale),
		vec2(-2*scale, -1*scale),
		vec2(-1*scale, 1*scale),

		vec2(-1*scale, 1*scale),
		vec2(0*scale, 1*scale),
		vec2(0*scale, 1*scale),
		vec2(1*scale, 1*scale),

		vec2(1.2*scale, 0.5*scale),
		vec2(2.5*scale, 1.0*scale),
		vec2(2.5*scale, 1.0*scale),
		vec2(1.3*scale, -0.4*scale)
					
	};

	float i =6.0f;
	float factor = 0.6f;
	vec2 verticesCube[] = {
	
		vec2((1/i)-factor, (1/i)-factor),
		vec2((4/i)-factor, (0/i)-factor),
		vec2((6/i)-factor, (2/i)-factor),
		vec2((9/i)-factor, (1/i)-factor),

		vec2((8/i)-factor, (2/i)-factor),
		vec2((0/i)-factor, (8/i)-factor),
		vec2((0/i)-factor, (-2/i)-factor),
		vec2((8/i)-factor, (4/i)-factor),

		vec2((5/i)-factor, (3/i)-factor),
		vec2((3/i)-factor, (2/i)-factor),
		vec2((3/i)-factor, (3/i)-factor),
		vec2((5/i)-factor, (2/i)-factor),

		vec2((3/i)-factor, (2.2/i)-factor),
		vec2((3.5/i)-factor, (2.7/i)-factor),
		vec2((3.5/i)-factor, (3.3/i)-factor),
		vec2((3/i)-factor, (3.8/i)-factor),

		vec2((2.8/i)-factor, (3.5/i)-factor),
		vec2((2.4/i)-factor, (3.8/i)-factor),
		vec2((2.4/i)-factor, (3.2/i)-factor),
		vec2((2.8/i)-factor, (3.5/i)-factor)
				
					
	};

	vec2 verticesCubeLine[] = {
	
		vec2((1/i)-factor, (1/i)-factor),
		vec2((4/i)-factor, (0/i)-factor),
		vec2((4/i)-factor, (0/i)-factor),
		vec2((6/i)-factor, (2/i)-factor),
		vec2((6/i)-factor, (2/i)-factor),
		vec2((9/i)-factor, (1/i)-factor),
		

		vec2((8/i)-factor, (2/i)-factor),
		vec2((0/i)-factor, (8/i)-factor),
		vec2((0/i)-factor, (8/i)-factor),
		vec2((0/i)-factor, (-2/i)-factor),
		vec2((0/i)-factor, (-2/i)-factor),
		vec2((8/i)-factor, (4/i)-factor),
		

		vec2((5/i)-factor, (3/i)-factor),
		vec2((3/i)-factor, (2/i)-factor),
		vec2((3/i)-factor, (2/i)-factor),
		vec2((3/i)-factor, (3/i)-factor),
		vec2((3/i)-factor, (3/i)-factor),
		vec2((5/i)-factor, (2/i)-factor),
		
		vec2((3/i)-factor, (2.2/i)-factor),
		vec2((3.5/i)-factor, (2.7/i)-factor),
		vec2((3.5/i)-factor, (2.7/i)-factor),
		vec2((3.5/i)-factor, (3.3/i)-factor),
		vec2((3.5/i)-factor, (3.3/i)-factor),
		vec2((3/i)-factor, (3.8/i)-factor),
		

		vec2((2.8/i)-factor, (3.5/i)-factor),
		vec2((2.4/i)-factor, (3.8/i)-factor),
		vec2((2.4/i)-factor, (3.8/i)-factor),
		vec2((2.4/i)-factor, (3.2/i)-factor),
		vec2((2.4/i)-factor, (3.2/i)-factor),
		vec2((2.8/i)-factor, (3.5/i)-factor)
				
	};

	vec3 colourPoints[20];

	vec3 greenpoint = vec3(0.0f,1.0f,0.0f);
	for(int i=0; i<20;i++){
		colourPoints[i] = greenpoint;
	}
	vec3 colourLines[30];
	vec3 greycolour = vec3(0.55f,0.21f,0.15f);
	for(int i=0;i<30;i++){
		colourLines[i] = greycolour;
	}


		//vec3( 1.0f, 1.0f, 1.0f ),
	
	vec3 colourFont[300];

	vec3 pink = vec3(0.84f,0.44f,0.38f);
	for(int i=0;i<300;i++){
		colourFont[i] = pink;
	}

	vec3 colourFontgreen[300];

	vec3 green = vec3(0.56f,0.74f,0.56f);
	for(int i=0;i<300;i++){
		colourFontgreen[i] = green;
	}

	vec3 colourFontblue[300];

	vec3 blue = vec3(0.47f,0.80f,0.80f);
	for(int i=0;i<300;i++){
		colourFontblue[i] = blue;
	}


	vec3 coloursforcube[40];


	vec3 whitecube = vec3(0.93f,0.84f,0.82f);
	for(int i=0;i<40;i++){
		coloursforcube[i] = whitecube;
	}

/*

	vec3 colours[] = {
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),

			vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),

			vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),

			vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),

			vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),

			vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),

			vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),

			vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f ),
		vec3( 1.0f, 1.0f, 1.0f )


	};

*/
	

//cout << Lines.size() << " " << quad.size() << " " << cube.size() << endl;
	// three vertex positions and assocated colours of a triangle
	

	// call function to create and fill buffers with geometry data
	/*
	Geometry geometry;
	if (!InitializeVAO(&geometry))
		cout << "Program failed to intialize geometry!" << endl;

	if(!LoadGeometry(&geometry, vertices, colours, 3))
		cout << "Failed to load geometry" << endl;
	
	glPatchParameteri(GL_PATCH_VERTICES, 3);

	*/
	// run an event-triggered main loop
	float originScroll = 0.92;
	float origin = 0.92;
	
	while (!glfwWindowShouldClose(window))
	{

		// call function to draw our scene
		//RenderScene(&geometry, program);
		glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);



		string ch = "Payal";
		string fontname1 = "CPSC453-A3-Fonts/lora/Lora-Italic.ttf";
		string fontname2 = "CPSC453-A3-Fonts/source-sans-pro/SourceSansPro-SemiboldIt.otf";
		string fontname3 = "CPSC453-A3-Fonts/alex-brush/AlexBrush-Regular.ttf";

		float scale =0;
		origin = 0.92;
		float adjust =1.32;
		
		if(indicator ==0){
			drawLine(verticesLine,colourLines,16.0f,programPoint);
			drawQuadraticCurve(verticesQuad,coloursforcube,12.0f,programQuad);
			drawPoint(verticesQuad,colourPoints,12.0f,programPoint);
			
		}
		else if(indicator ==1)
		{
			drawLine(verticesCubeLine,colourLines,30.0f,programPoint);
			drawCubicCurve(verticesCube,coloursforcube,20.0f,programCube);
			drawPoint(verticesCube,colourPoints,20.0f,programPoint);
			
		}
		//
		//
		
		


		//float scale = MyGlyph.advance;
		//scale = 0.4;
		
		else if(indicator ==2){
			Alphabet.LoadFontFile (fontname1);
			for(int i=0;i<ch.length();i++){
				float space = drawFont(fontname1,adjust,origin,scale,ch[i],colourFont,programPoint,programQuad,programCube);
				scale += space;
			}
		}
		else if(indicator ==3){
			Alphabet.LoadFontFile (fontname2);
			for(int i=0;i<ch.length();i++){
				float space = drawFont(fontname2,adjust,origin,scale,ch[i],colourFont,programPoint,programQuad,programCube);
				scale += space;
			}
		}
		
		else if(indicator ==4){
			origin = 0.975;
			Alphabet.LoadFontFile (fontname3);
			for(int i=0;i<ch.length();i++){
				float space = drawFont(fontname3,adjust,origin,scale,ch[i],colourFont,programPoint,programQuad,programCube);
				scale += space;
			}
		}
		else if(indicator ==5){
			
			ch = "The quick brown fox jumps over the lazy dog.";
			string fontname4 = "CPSC453-A3-Fonts/alex-brush/AlexBrush-Regular.ttf";
			Alphabet.LoadFontFile (fontname4);
			for(int i=0;i<ch.length();i++){
				float space = drawFont(fontname4,adjust,originScroll,scale,ch[i],colourFont,programPoint,programQuad,programCube);
				scale += space;

			}
			originScroll+=0.015;
			originScroll +=speed;
			//cout << originScroll << endl;
			if (originScroll >= 12)
				originScroll = 0.92;
		}
		else if(indicator ==6){
			
			ch = "The quick brown fox jumps over the lazy dog.";
			string fontname5 = "CPSC453-A3-Fonts/source-sans-pro/SourceSansPro-ExtraLight.otf";
			Alphabet.LoadFontFile (fontname5);
			for(int i=0;i<ch.length();i++){
				float space = drawFont(fontname5,adjust,originScroll,scale,ch[i],colourFontgreen,programPoint,programQuad,programCube);
				scale += space;

			}
			originScroll+=0.015;
			originScroll +=speed;
			//cout << originScroll << endl;
			if (originScroll >= 15)
				originScroll = 0.92;
		}
		else if(indicator ==7){
			
			ch = "The quick brown fox jumps over the lazy dog.";
			string fontname6 = "CPSC453-A3-Fonts/Inconsolata.otf";
			Alphabet.LoadFontFile (fontname6);
			for(int i=0;i<ch.length();i++){
				float space = drawFont(fontname6,adjust,originScroll,scale,ch[i],colourFontblue,programPoint,programQuad,programCube);
				scale += space;

			}
			originScroll+=0.015;
			originScroll +=speed;
			//cout << originScroll << endl;

			if (originScroll >= 18)
				originScroll = 0.92;
		}
		//RenderScene(&geometry, programPoint);
		

		
		//RenderScene(&geometry, programQuad);
	//	drawFont(&quad[0],colourFont,quad.size(),programQuad);


		
		//RenderScene(&geometry, programCube);
	//	drawFont(&cube[0],colourFont,cube.size(),programCube);

		glfwSwapBuffers(window);

		glfwPollEvents();
	}

	// clean up allocated resources before exit
	//DestroyGeometry(&geometry);
	glUseProgram(0);
	glDeleteProgram(programCube);
	glDeleteProgram(programQuad);
	glfwDestroyWindow(window);
	glfwTerminate();

	cout << "Goodbye!" << endl;
	return 0;
}

// ==========================================================================
// SUPPORT FUNCTION DEFINITIONS

// --------------------------------------------------------------------------
// OpenGL utility functions

void QueryGLVersion()
{
	// query opengl version and renderer information
	string version = reinterpret_cast<const char *>(glGetString(GL_VERSION));
	string glslver = reinterpret_cast<const char *>(glGetString(GL_SHADING_LANGUAGE_VERSION));
	string renderer = reinterpret_cast<const char *>(glGetString(GL_RENDERER));

	cout << "OpenGL [ " << version << " ] "
		<< "with GLSL [ " << glslver << " ] "
		<< "on renderer [ " << renderer << " ]" << endl;
}

bool CheckGLErrors()
{
	bool error = false;
	for (GLenum flag = glGetError(); flag != GL_NO_ERROR; flag = glGetError())
	{
		cout << "OpenGL ERROR:  ";
		switch (flag) {
		case GL_INVALID_ENUM:
			cout << "GL_INVALID_ENUM" << endl; break;
		case GL_INVALID_VALUE:
			cout << "GL_INVALID_VALUE" << endl; break;
		case GL_INVALID_OPERATION:
			cout << "GL_INVALID_OPERATION" << endl; break;
		case GL_INVALID_FRAMEBUFFER_OPERATION:
			cout << "GL_INVALID_FRAMEBUFFER_OPERATION" << endl; break;
		case GL_OUT_OF_MEMORY:
			cout << "GL_OUT_OF_MEMORY" << endl; break;
		default:
			cout << "[unknown error code]" << endl;
		}
		error = true;
	}
	return error;
}

// --------------------------------------------------------------------------
// OpenGL shader support functions

// reads a text file with the given name into a string
string LoadSource(const string &filename)
{
	string source;

	ifstream input(filename.c_str());
	if (input) {
		copy(istreambuf_iterator<char>(input),
			istreambuf_iterator<char>(),
			back_inserter(source));
		input.close();
	}
	else {
		
		cout << "ERROR: Could not load shader source from file "
			<< filename << endl;
		
		
	}

	return source;
}

// creates and returns a shader object compiled from the given source
GLuint CompileShader(GLenum shaderType, const string &source)
{
	// allocate shader object name
	GLuint shaderObject = glCreateShader(shaderType);

	// try compiling the source as a shader of the given type
	const GLchar *source_ptr = source.c_str();
	glShaderSource(shaderObject, 1, &source_ptr, 0);
	glCompileShader(shaderObject);

	// retrieve compile status
	GLint status;
	glGetShaderiv(shaderObject, GL_COMPILE_STATUS, &status);
	if (status == GL_FALSE)
	{
		GLint length;
		glGetShaderiv(shaderObject, GL_INFO_LOG_LENGTH, &length);
		string info(length, ' ');
		glGetShaderInfoLog(shaderObject, info.length(), &length, &info[0]);
		cout << "ERROR compiling shader:" << endl << endl;
		cout << source << endl;
		cout << info << endl;
	}

	return shaderObject;
}

// creates and returns a program object linked from vertex and fragment shaders
GLuint LinkProgram(GLuint vertexShader, GLuint fragmentShader, GLuint tcsShader, GLuint tesShader)
{
	// allocate program object name
	GLuint programObject = glCreateProgram();

	// attach provided shader objects to this program
	if (vertexShader)   glAttachShader(programObject, vertexShader);
	if (fragmentShader) glAttachShader(programObject, fragmentShader);
	if (tcsShader) glAttachShader(programObject, tcsShader);
	if (tesShader) glAttachShader(programObject, tesShader);

	// try linking the program with given attachments
	glLinkProgram(programObject);

	// retrieve link status
	GLint status;
	glGetProgramiv(programObject, GL_LINK_STATUS, &status);
	if (status == GL_FALSE)
	{
		GLint length;
		glGetProgramiv(programObject, GL_INFO_LOG_LENGTH, &length);
		string info(length, ' ');
		glGetProgramInfoLog(programObject, info.length(), &length, &info[0]);
		cout << "ERROR linking shader program:" << endl;
		cout << info << endl;
	}

	return programObject;
}
